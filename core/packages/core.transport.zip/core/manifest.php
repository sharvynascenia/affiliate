<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e1b840fb35c16a55d9f4bffaa26a888b',
      'native_key' => 'core',
      'filename' => 'modNamespace/37b8e37ca7a2a65a2ea0aa3e883241c2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '83d6c6a52e168b7b25833cc78f90e6c1',
      'native_key' => 1,
      'filename' => 'modWorkspace/0340f9aabd4f51b7bad57662289b5e09.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '2b1e0dfa4a1019ce9bf6d0e3df58d476',
      'native_key' => 1,
      'filename' => 'modTransportProvider/ddaa1c9030d11199f9cb773c69cfa36d.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7f3d280a774d1f8963dea61d7748ee3a',
      'native_key' => 1,
      'filename' => 'modAction/23d9e7e4099baacaeda3977c7ee741ef.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7393e9758a6125678ac8b6d444ed7272',
      'native_key' => 3,
      'filename' => 'modAction/93555bd679452bbd73f8179863dd418c.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e32280cea0240e364f0ef932b99aced7',
      'native_key' => 5,
      'filename' => 'modAction/fa1e174932de14621cd5a8bdd899df00.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '58777457cb6c0889fbb0cc3fccdbe4ec',
      'native_key' => 7,
      'filename' => 'modAction/a7f062cb2c74054d76a05e03fe9b9f87.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '69cf8c5309aa83a102abc85ea5a89e6c',
      'native_key' => 8,
      'filename' => 'modAction/c2e44b449dd9a491f1795417d56d0943.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '41ee138315251cd3d401fd2caac078b2',
      'native_key' => 9,
      'filename' => 'modAction/e63d40fb507406d9a7f991cadd19f8db.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1e67a28761d5bfd6845c9715bf2b536b',
      'native_key' => 10,
      'filename' => 'modAction/dc70f92b10360012bd4fe264a0639179.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '946769e9f9292c4a28ab3b6aa6455264',
      'native_key' => 11,
      'filename' => 'modAction/6b720e61d54b69502569c7780bb82780.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '752206ad72ddfb7c0d628763ed592aa0',
      'native_key' => 12,
      'filename' => 'modAction/5cc6adf1b40307281d4dba6ab9760d82.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd39a94d11dc75e625264e6d4ae274a4c',
      'native_key' => 13,
      'filename' => 'modAction/95363fa35fee4e3404dc1929d13053e4.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5f4c432b9f863c542ff325c22e143e35',
      'native_key' => 20,
      'filename' => 'modAction/8a4aae3b4695d1890428e9c5bc9c36a3.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bec61f9a9cbef5a401c0612b4b1ef3a9',
      'native_key' => 21,
      'filename' => 'modAction/8449f7ccae6d0a7646df0ea39eadb4c4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7fce7daf4947b9e75edff908395ea7d0',
      'native_key' => 22,
      'filename' => 'modAction/1696e23a63def7584be10c14aa9ae443.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ce6971bdfb837854f66c3ec9b3d63b63',
      'native_key' => 25,
      'filename' => 'modAction/7abd2599e9d98a7bd6bbdf495a1e79ff.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1f8f8f1306190a412c040ae1a4a7c907',
      'native_key' => 26,
      'filename' => 'modAction/919b558ab7f16421eedf5dcc9d912685.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '09e023c2907976538280954b78849bee',
      'native_key' => 27,
      'filename' => 'modAction/0085d90dd941ef4b580d8ee1f44d05c5.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'abe13fafb852145dc94599f41e9d4a38',
      'native_key' => 28,
      'filename' => 'modAction/63d9389beb945bfbd0fe49fa16b72eab.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9684df8167c254e0efc5e74f35290b1d',
      'native_key' => 29,
      'filename' => 'modAction/90438e7262b1662f35df000f6a6499be.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1dca1eba189b1696108c0b42cbf2fbd7',
      'native_key' => 30,
      'filename' => 'modAction/90cf884979a3e189eb218d94de4ab149.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2ed3296956d6150b3fa3578022779277',
      'native_key' => 31,
      'filename' => 'modAction/8974377e9d0136bef4b1f0d1fe325093.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ca2aacfa44b1511ad321a9043af9d36',
      'native_key' => 32,
      'filename' => 'modAction/19d1c1d0f63f258e771e515d7bc2c1a4.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd0fa4195a1f6e8c3c338b0654c9bb84b',
      'native_key' => 33,
      'filename' => 'modAction/eef4adf669581a1bde7bdd33eb7f4af3.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c8b8dcf5c1233b1a6502c5ef61b5421a',
      'native_key' => 34,
      'filename' => 'modAction/46b91f53f8cedbc4c56fe07aa5ebdf4c.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3c1dfade87f82ae9efe5d23a6ada75da',
      'native_key' => 35,
      'filename' => 'modAction/460a011447da7b5e198f0d17aee081d1.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4fc998e1b2034e6f05ac98779af9035a',
      'native_key' => 36,
      'filename' => 'modAction/99095a20ec0467ac24f331761c81fc45.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a61e8d70442253856fde8903e5a33417',
      'native_key' => 38,
      'filename' => 'modAction/5449d4d732d5e166cec48ef619879eb4.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ce04c410d6eb1d306734b1abf87d5e2f',
      'native_key' => 39,
      'filename' => 'modAction/68b255b9164aa12836d1abc932f6fb28.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3e125316b2b7d576093911c06844e187',
      'native_key' => 40,
      'filename' => 'modAction/5241e32e1fe02e152b54699f9fa3ee34.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5b706d8ed06d8f1cbf1dc2b403a78b61',
      'native_key' => 41,
      'filename' => 'modAction/37c4994082a9f28ee391896e107e09fc.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8511174aafe2c3d26c0d9ca2ddcd3b92',
      'native_key' => 43,
      'filename' => 'modAction/89cfb819642c2ef4ddb58f2350e1348b.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b36fc5c093691b5e78123e238c67e7af',
      'native_key' => 46,
      'filename' => 'modAction/b06efd81579e6a17313ce1deb4e163c5.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7e9b6bab43fc12f965008d2bf4f15d50',
      'native_key' => 50,
      'filename' => 'modAction/6b49c036557ef32a8cbf9a773cdbda6f.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ffc8480c712fbe759534b65b38eca6dd',
      'native_key' => 54,
      'filename' => 'modAction/5a5e61771a2e754f18c04bb8194a1146.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b428f23053c5ff3487ac105071c71ddb',
      'native_key' => 55,
      'filename' => 'modAction/76af3288c9845e6d77a07da238af8b87.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b17f3698bb2e72d4a623883efe7b42a7',
      'native_key' => 56,
      'filename' => 'modAction/9878b7045ede3b67696960328730e261.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7eb8563472caec6f9a13a61c50f8f7b3',
      'native_key' => 62,
      'filename' => 'modAction/383c78cf6b900bac05ebec04270626a9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '324d16e62da970b166f2cefdd7006c35',
      'native_key' => 64,
      'filename' => 'modAction/e65fab68638bf172ddd117ba9ef3a6dc.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bfbd264298c68d92fe0803627e763d3a',
      'native_key' => 67,
      'filename' => 'modAction/2b06f95dadb132e1eea95bd827c51dbc.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '65b2252648adcbedcf10037fdb539732',
      'native_key' => 70,
      'filename' => 'modAction/3c4af95b1d5d4b0851ee1481e4a4677a.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '73f21eda8d58191a79c0797ab43320d6',
      'native_key' => 71,
      'filename' => 'modAction/3223af7471ae7db0809383e4686a73d7.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '28a39cfdd0396ae3c6f8e6b202aaf702',
      'native_key' => 75,
      'filename' => 'modAction/8c219e5e38134441c7ac3c6d430e1707.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f5893ed8b33efd50082adce3d30926da',
      'native_key' => 82,
      'filename' => 'modAction/9cbf149b487dea90c3682d9159588086.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e94ef8038f3bed5870b076b04a7ab54d',
      'native_key' => 83,
      'filename' => 'modAction/5c714e863f1f511680f1e4add7acf9ec.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '02995430a6445d43478f1a40ba066ffa',
      'native_key' => 84,
      'filename' => 'modAction/4649f5dd8f9b871ae8a9e0fd0510c04e.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '676d88ac31706e82bc221935d1c5afee',
      'native_key' => 85,
      'filename' => 'modAction/05594f4c43e557e33f3a13dcffd75795.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b2e850efd3e035f74bfb703878bb8ac4',
      'native_key' => 101,
      'filename' => 'modAction/7f8dab4889ddcd82a487d5a2ab1d081a.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f2127c01d01fc85a16147a26bdfe481a',
      'native_key' => 102,
      'filename' => 'modAction/5d5b87d78f3b0e8db08460ca1faf439c.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6039d30de042635f1f8e33c4e0c44d51',
      'native_key' => 103,
      'filename' => 'modAction/351b8fdfb2a584abffa0459dc148dfd8.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6d07208d2ee3cc92817967da41cef72d',
      'native_key' => 104,
      'filename' => 'modAction/cc4c801fecb52134f4d8d79bed54ba42.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '054f2b0fa50724beb5671358e63b2ec3',
      'native_key' => 105,
      'filename' => 'modAction/22e41617883ab5a0425bc3bc45d82c23.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '97f62bf736ca3ce17ae0c37e99d6e8a5',
      'native_key' => 106,
      'filename' => 'modAction/78935fc7664b2eeea020e2441532e686.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4ac15bfa2b69a0924637728635f3361a',
      'native_key' => 107,
      'filename' => 'modAction/6d6c85d6c2fa079e92d5809bac558642.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '601b0ca13d06da113d5b1fd6807f41a8',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/68abc9d6b8936b9a834834b92322a4eb.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '13637496013dad7dffdb891bd1b7e192',
      'native_key' => 'site',
      'filename' => 'modMenu/45eeb85c9222a6d884cb4d22da07b681.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1a2449b5297acd3c740748bb40b8d16d',
      'native_key' => 'components',
      'filename' => 'modMenu/6032f3bdd95e979d456dc605e8d57566.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4d7099311bc9caf5212ba00439c1f116',
      'native_key' => 'security',
      'filename' => 'modMenu/2131186ef2695c2ce952535a6d86189c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '552fc9a043403e14d746bab9ec91d571',
      'native_key' => 'tools',
      'filename' => 'modMenu/6080641e02def440c3d186e3cec1ad38.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ec211bc6960ecbddd213d2bb162ab7ee',
      'native_key' => 'reports',
      'filename' => 'modMenu/a9e17792906f8fff0aa03ebe604f723e.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a3a695494c69058e0a38bdfaffb7fe17',
      'native_key' => 'system',
      'filename' => 'modMenu/5f5502ba77bffc03d4b22826a77a40d6.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '477273ca450064dac907b58057812e87',
      'native_key' => 'user',
      'filename' => 'modMenu/efd5a4bbb5062d3f902cace251c97b70.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '51aa02c85d4de8e28637e64784bed727',
      'native_key' => 'support',
      'filename' => 'modMenu/84a87f6601a5eeac9d039b29527170fd.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '302919bfa9c938f868ab64be99d049eb',
      'native_key' => 1,
      'filename' => 'modContentType/54d3ab94ab68b25578cf030f3b409a50.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'dd24544b1cc09a8e6994df3984d133eb',
      'native_key' => 2,
      'filename' => 'modContentType/a031a60959aabe9d660eadd97001a4d0.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '417e476cf27e5ccd75a1cb95a06a422c',
      'native_key' => 3,
      'filename' => 'modContentType/51080dd6e4a985326b52518b6e11cf28.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '92ab3ce1a7372a61e83fb3edea164993',
      'native_key' => 4,
      'filename' => 'modContentType/b73761baa5b22e481dc4ca2f57153ae6.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '60aa02e1c5044d575f34bffbb2a13221',
      'native_key' => 5,
      'filename' => 'modContentType/9389b2fadda5ef2212315b8928192b77.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a03d3db3b89ab52416c3915cf5d22010',
      'native_key' => 6,
      'filename' => 'modContentType/51eb2c5fce435e9f4a1c254c73f88fd3.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a1abeec036e5f6957c107c3f09f5eda6',
      'native_key' => 7,
      'filename' => 'modContentType/e5e2a3d31bb60641798e80853b77db0a.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9716228de96cdc8e3ce8ce6e085bfe50',
      'native_key' => NULL,
      'filename' => 'modClassMap/679d6b12d4a047521cf8aa3b39f8f469.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd371816ed0c40efd0cbf0987fb9d44cf',
      'native_key' => NULL,
      'filename' => 'modClassMap/d0093db014f850c57d6451194fb638a8.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd5fae26a349fb594c6114c9f82e99fdb',
      'native_key' => NULL,
      'filename' => 'modClassMap/0c1c61baa0c4f888e9266dab90e9e805.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '82a002c31cda6d7c7226837549fe85b7',
      'native_key' => NULL,
      'filename' => 'modClassMap/a633611b4e54d505543d42e1a5f1ea28.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bfe21aceb3ececa7156e09d354d3f55d',
      'native_key' => NULL,
      'filename' => 'modClassMap/2939319c24758154228511b14cdff684.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f7b03b69bbbf1c1decede3c2ef732fd6',
      'native_key' => NULL,
      'filename' => 'modClassMap/325eb22ad44eeaa8222e7ee8347bd054.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a4df2df62ebadd83dc97c73c30534abf',
      'native_key' => NULL,
      'filename' => 'modClassMap/e90cd995f1a7b70b02b491b28deb755a.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ccef33216fba5dc1ab5e42ef9da368d5',
      'native_key' => NULL,
      'filename' => 'modClassMap/51deb5f5e87a94c63cb3463a18f8a973.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b42cb0c947231fb67e800ea1ab73bff9',
      'native_key' => NULL,
      'filename' => 'modClassMap/80603b43b3efcfb7bdab34a322a0b563.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fed6134f34e1060760a4f2cdc2b4d0c',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/ed814d433dbc1eaca53df4cad2a8e097.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '657a6b482cc45336d26679fcb15815ae',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/6fb9dfcd203ee05f8f054d1017e808b8.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c792957b871011f5e99b7caeaa32a79',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/902f9e0a40c31b2c4e3718044f42b52d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '721f0bfbf028a4319f1d12f8a1a30bb2',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/add0354ca3df7cdf85aeaef3609626b1.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80ccdabe468f16bc17eecf1e31a4ca7b',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/b146cec00d5c94034b9d35b1713d7fa8.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f90a7a4c9ced332b10eb283bbbf6377',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/ce438d2dd8c52e1b2d3aed46713643a9.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3264a857d4dc2c442e9f104fe06f4d0',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/3dd071b1c629cabfe96fcb2ee7ac634b.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d87bd00f251fd5b69894eae793f7637',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/93026b2b243b9c945041c19f74cb63f2.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a4fc04c4536af509b46f4ba312f8d71',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/9d3a368f56fbc643099965e2eacfa1f3.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88fbe1d5326966cfbad700dbc637f04f',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/2e3c349c72115b03d9dcbc3b9144184f.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '192fe261932bf14b9bfdbcdfe712df10',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/cd37d6199cf88912c7908154015362f9.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeeddb0d9d57782c859ae574bc25ba10',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/5905cec7ebcdf79dba0b49b738429afe.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b892202d6a62b57cdecda35357146c3',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/ef96da2b7c944ee99a8f3e361352f20d.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e5cadcc14943ea22ea74cb357a6d703',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/a07fd7941fb5379e94edf0c391044df1.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b478240c39d85bf02b6abc53ee74e61',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/e97071894b73eefe35d66498482e75f8.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9df48b79ed6a679cdaa5fc1ca3a432f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/73973b2b615017f43461ca4654298867.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d9083b0cf77690a31f6ccf8fe4cd64d',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/c5727647104a876f89bbf5342c44bf05.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3c05f5d08e7cea099fc6acf63373ce4',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/5c7c230e67accd5c0efc35ec6d1b5091.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2eca85eab4ca55cb6af6802c3b477a28',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/54d05d10dd538dfa9d918de41513785c.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fc4ee86c4482b86360929316512411c',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/534be1d75906dff01b52a3adde2500d3.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '235f32d419c925f21da76a2e7824b8db',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/3ffe0e58af13b4a34a838e8dba539271.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4f86765ebc78e8bb6eae00236a009c7',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/c4712971c436e603e77ee6d67f753f23.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05d7ffc80ca78e821acd5495170fdca5',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/1d291f6133fefa38a542e8dd48ce8549.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fe6421f28a122af76b1c468882ab98e',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/82dcce5ac99a289eac4586b65f083791.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d1aa80146bdd3e0042e96f46d13c0ea',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/11cb617da64b9b8434828f993f978442.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a9efc751b61a106cd330adf9bd8135c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/bbbadbd98ca0bd1c5e613151fe128a57.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '498cf42eef69edde539bad18856c67db',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/9d870e4ac655f7f9845d593f517a3e92.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd92ddc95b46e0dad6b26aedb0298e5bd',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/15c5b19fab5c34b7bba7e9e0d4e43d0e.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40463b8003270345d51633a2acb09d3d',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/e7cacadb115b67cdc0f31805422c0785.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb189a367ba64e0eb73592499b4c8f33',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/4bd4f4c1c08f05549cab4318a7d44352.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe96e8d9c155cb7807f8acb4ea38b276',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/23547a184be5ff79e1f8d753d6989edf.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c7fa1316761f95e3118cc4e1dd4d4dd',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/6a15de5fc77ffd7c0423dc51800ae3d9.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7af407e20b82d1b933fe55b0c5f566a',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/371aff57d66bb204c9b15f204422fd00.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e37d0ac53fb21787973fa8832e1e374c',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/1569795776939cbdff582654922e201d.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81e12e6a3052f5e485773f7772bcbff6',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/09f1b05dd3d6c9b27298535eb4d6b823.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5391040cf7c27314c76d907e5930aad4',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/be011b2ed56a2a3fd0a229beba244387.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '851aaf7af4aca6c1725ccbb820f07977',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/b31ac0523fff1208ddcc9f4f13543514.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '530264b27ad9967195c3473b24d92f09',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/5b968e006972f89703d9de21e0106447.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bccb784d3743fc1780aae5f7bb012f7e',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/5e1da8e5e568065c0efe6294bcdf904f.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '840fa5a44def70ca07dc3abf6c4e9561',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/cb37ff30594fee4dc8eb81a596375076.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11459e34e7dc6eff2025a2bb371b06e4',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/838db25a438958a0c533b694b3772d72.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fdd2cd47981ac2b0251a414f4e00d31',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/09127288f4192d55c00c38e0bc4ebe4f.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45f76e1d84573604ff258243e9bcb004',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/4dc96da255a4608739d05f7a11d461ae.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd92c1b90188d724b95ed03f964272267',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/25fdab01d917e633df9212b677889524.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3fe7ab5575d0f42a334228e260d862e',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/35e3ccb682f1750a26d1cc660a4c8b09.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e2c5577f46eacd92595c9679ca19547',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/5fb4be8223eb01d21d692816b01748aa.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b10ebad260e50120aea63e06219ff425',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/f87717cae8f25c2e9cac58b1241de827.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc4849c17e4b3eb6ab3eda9460e70b5f',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/eefe0d3bb20c4139137ee3f6c34317e3.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41130e33040cb0a5fef24133a5af88f6',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/487d3986868ff1430f5379598c1a8c46.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c92dcf7eecac60aaa2b86528820ce0df',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/347ba954eb528408a345c0e2cbb2fe3d.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1608624d9ab0efeba8fa16d9112fdfb2',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/d3486b18df6380cc31d2fc31aaba9501.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ae7e53fea6741c3837158b16c89a388',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/52486e17b6ce17c0a218fd165cbb6733.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51a67091695432eda1bbc73cee30cbb0',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/cb732e02ec6df2eb55a58d1f99c13c87.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fadcb217fb85d44fff15500a71f7837',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/82498d90ce8f00e8d24b8330e8d3bd06.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dec699352b6efb17a5287f8736ec842',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/db1488352e0627fabf8ef16ab159f1dc.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5ad24700e430eb8e9ca791ae7f21c29',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/7cb9630cf4b0984d17738196c9e805f8.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b52ee8c6748d89ba22c84e6a24174e04',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/3c6ef1dabffc5e835e6ddbb2e95f6a9e.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8170ca237d247591c7041d149554c145',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/c64a7dab288cca2c2d40c2a449ac72c9.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0c184a8f9d9d949972db5d4e33780d7',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/27c29ac9bee0bdc9b47985b83fa5d326.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c93a8eae90f180857cc692f4efcd0393',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/1812fdbd4ed8880e4dbe5224017f9426.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74cd5a3db02179dc8c4d512092d20adb',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a2fb8ff1e439db78b9b33f900b269296.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a582d3435ee84b63b7ea7358469f104',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/2bda0f0408965a87d8ef5f5ad17f69af.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c5d67b95cc40b627e08577f9a243546',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/d3ee3459b877eadce28411d7890e4b00.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5245df654c7d0d797d87ce4da82cffa6',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/6e81f49fc66194e44e35a8bb2a99f2cd.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6e6fe9fa1b93b2988aecbba2d46433c',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ceb2ddece381fa3cf3d9261bdab64d9e.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '840651a8649070f460f49022dcd6f661',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/fe867b3495055fa1fafcfcd5de085f30.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7580af164ad9c29f63876828b8bbf43e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/4a72f1f9f4fdf822ed13f83f9517d04e.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a6a1d0a70d6fb281b4886994f0eaf34',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/e389246ebb1dc7557b145c35fa88fb00.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbddf5f5b4af2602df6b6ce50929b0e5',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/9131b63cf9d084513626ce5d7ec5abf4.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '777d99867bc99aec8a1b1be92c6f93fa',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/dfd10969f051f39743add11f22cfad83.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '013566f0586e4815d4fb03a52e462aae',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/b7b9963d2c56e78798e54168afc986fc.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70655e44d028a2af5c36e662f3d1df5',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b3a7e738a66f73250af8a88af95615f2.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f9c6cca5016e2485edf57cb70b3f012',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/4b21e63ef9538ad85cf991312c5a580e.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23ab17a722f2541e0b48e22d68d04e40',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/8dd986443254d560be71a10f5bc8d7d1.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5563532a8f8ce36baaf7cd3e467915fa',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/950c4b5e7b0dc67e045d5796583184ae.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96bec672a2f2c4c2891e37748383071b',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/6fa37a5aee1150df476bf2133e953898.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06f02dce8b00794713dcf055c821623c',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/9024542a9d22a844da929ab10fcec80e.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '111838bd02b8512d412f7fc80764690a',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/15ea2fcc67278841763d56dc1259ee81.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '291a999713ded8a5c4facefa5f24728a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/8f12f4869bbf3645716e5e12a6e505f3.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e726b5f8c7ab5f6a8b8ca3c3ecd8058c',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/73901fc054bfa29c48612fa2b730a70b.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71dcd67924eda5f128c71f9ca893efa9',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/a004d29d043ef68f5260b1abf651743b.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d2b29c13961db9c59ca4da8d2bca08a',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/6ca368205728b729085a64b092690ae2.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c31edc18f786dfd3a82e028bc229a9de',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/c916940547789c853bc48f251bea1a5a.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a2c1bc11b8def5467dc57d5ba9238f2',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/b416e6c80eedfcb4edb47ab35eae4fad.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd251d8a2173b28d141baafec11cbb651',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/e4e0391bc26f5598c7027a63156dfed6.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50854fc1420ab0073165ce293b1476a5',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/8055b0422a025a8fa763a9c29c13c548.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60d45246626e80994ae7b9a2ca9ec22d',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/8c74b698f67c8494db27021c3edc973e.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a4de038a71369ea2a6b21d708e9bbe6',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/ffca6b594c0b9be59a156a2d31b517a3.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89e6a2d359be73ed6fbc4fee70c2ddfc',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/35f84f0506373e2dc463c63501e53f10.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aedd99ba3cc52763e2f9275202ca7b13',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/1b73c032bbea16dfdfcd7e5cdabb8fb7.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90c5225e41c367d15fc085f6320d937d',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/b7e5105358ce35aa5ec45b50ef5522d6.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28fa9f33032d391b079ae8acc69aaba1',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/3abb451fe69e1d47484886a23f2f7bcd.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b43d1305e045ce8deb96adbdbd86c878',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/80740bbd8ffaff49517a58c35161dcff.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c3f0b8da8e04b33cd726a491ebf2d0f',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/8b05792d7cb3967391be8feeb9092d26.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23993d6e618a042be88c33c3286cb2a9',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/8abd935842f27f2a34075c5ad8d14a42.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c09b3a438fb6533f5ca98af62d76a6f',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/b6827f07bf0695ce6bd5f976fe0a9c37.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a6bb535453c1648a251b042a5282757',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/1ede70d501d1cb689f4ba7edee7e2862.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd05cd26013fba77e63701f6adb8a9752',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/ef72469ebdd2d816e3d8628b9eb0a661.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55b9d91e1b6379cd8b499ea41966d02e',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/00303cf73d69e7568a25711e91829279.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78be308ec2aeed082d2b335fe76005b1',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/9b80f50abee02eaad28039e55e995f3d.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38fef0e54bcac012d2b968d1affa3acc',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/bd374f909647cdaf1cdd22e550ff1b94.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6f13f8f2c2c281728a8a1dbd4aa8017',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/214c8ba049a90bc5114fb7efdbd9e7ec.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aa086ba0dd4c0c631bf611bf71fd97d',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/c828dfdbd3a4fb4e64f852b5eb3a19ce.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6fac851cda0b4f8252718074657d213',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/41eb0a8ee810107a50c155e38f99cd44.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd21dd9987a5a2cbf4ee9329909151a4a',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/62d1fdf419c023370c39a814a8317378.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0d4a94ea0a07bbc5ab45ed3736d550b',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/e18e06d76c82683a840a64fcc93ebc40.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0975714cbf33ef02609307fca1fea09',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/f9934513e9fe1827edf4339c083f3c1f.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4df77f1e14f3acf0fab6e1ad15d3648a',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/ed6769573c10084a6efb9c5c1a90e946.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fa48273465852b650646597ed3574d3',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/21b0f4d535c95b970f1bde7360bbde0d.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efa59d18605f1c38827d0fd9914f8756',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/2d34a62a4b5728cf9c143d1e10766a18.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b4824cf493b3aa09f493ac71297a7d0',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/696fe9b7115b331a37ad11f218eed8c9.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e947bf92019ddc939e6ebe1afbaa0749',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/522fb5c34a5756b7ba0722c869a332fb.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '454f0ef8a16a65f4cc6b09bf193556ef',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/20eebf35eebe209ac5c8208c4706cbca.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5c7368cdd5acfb3bc5f4bfc2ff7e165',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/2465cf979982e050579af98ccf4b26bb.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '011164cf8379cdf6f97e09653d246874',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/3986925b8b6c049606430058f23104ad.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c19a7c28264067d0a5eae3e5a7b6f4e',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/047a23451acbaaef4a0de2e15bf957a2.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9275e2802754be60041797015b6ed6bb',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/4173df3fbcb44c635c8b17340b82799d.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78563289e4340ec9c78ceab84b0a253d',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/597b9601a3433a46b39301b7dc06fdb6.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a00926ede1dd2e9b9defbe9b51411f42',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/2406950236319def71bb2c98ee53eadf.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f469f8756fa665a73d19cca9573eba0',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/598d77ff54088c7da9eb0e3ab8988b07.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59fc7961bb230d2e2dac1f25eb46b810',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/efc71c4a3c338dd0b6b1c027ca488541.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ebe80506d22300e5184b93bb62ab16b',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/2ef7a904d84b5e985a97fc5e4fe06b1c.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7e86bac39e11cc82d35179e74e27583',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/96e457223dc82caf813f00df599799ea.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98823638a38abc8619e394fc625d9345',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/b0d794ff4f8bf5229883f8627f3aca06.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1226655500c7fa319a89f17b054e48a8',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/1b429139e59dd7240dbb22a785409193.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9987f995ea9d61764b051ec7ef68c30',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/a52f69d999c2475bd18ae619b1bf1c5f.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c382c79851e498dc234f687a2fe3b6f',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/a587f1b8dc2af73dd19545edc5cd26e7.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d9b6bc1337eb30bfbbf741e44eea3a1',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/f8a4f6af2b16c6db6c8b08c20e59c5f3.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60535a8f2ced19aed539b6057fe64a91',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/2ff99750ea11461dd90856e33a2aca75.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5eb370a9856a25f7dbbd4096dce2ff6',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/bc5cc0335ff6247cff08a36542bfa9db.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91a2803e42f3ef66917bd25bd0517b43',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/c65b6fe323306e85ef102426557e02ff.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2204afdf774a696e7388fdc7a913a52a',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/6b441e8adacae3ca3725c05fdaed80db.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4343d157542de46dd557bf10a2e79eb4',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ff9b031910b6b8e4ce6e074367550dc7.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7476302d7bc51442808ae651066f8d92',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/1d4d1d726cddb1a2f55a9c67bfcd37d6.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '248fd2858cc4f05ac2fe6d3d700cbdcd',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/b660d58c8a31ea8331f4b8ecabc49aab.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05462620ecad068e37bbef12308281de',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/e7ed4f38b2f13e7c78310ca0254017dc.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b2f76e97c90d20f79effc60fb5ddbe6',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d968ee1832dc792c2ecaf737318fd48e.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38466d83a478b002c7aebdcb91ac6d08',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/1eee8f4dc951a45d462fa9bec0621c86.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f8cb5780131444b74d4e1a2b2aa83ae',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a91778a8fbb343bcb33d04a6ecfcfe60.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aff090fc7d52f4c4474513dd6a9037be',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/15f2ac41d652367357e038b392226de8.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9fee79d1cc28b50501ed550dd5109d9',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/c766cfaf1ba851c7f1f5eb666be5b503.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02b36f7eebe1d6705814f8303516282a',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/5bb432259fec09b37d3640c407077c05.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a613deb0d9bcdeb0341d4d7dba8e73dd',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/36bd6036363aff256d00d636f1ba1131.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48c8d3acfb80c603f73c605c30890210',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/f0e24d7c33e742eda93d27ad68f46a19.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91d1946937aaf301bcd81aab28d8aafe',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/75dfc6e4a8936af8dcb605d047b1bf2f.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e0cbbaccaf9f106282077025859d9f0',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/1eb07609984fbcc1981ae5539539ee61.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c766f291c992753b1aac387645621f5d',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/ce7301c5b1a2acf7a134ca45fb34687b.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '996180d9e9913d91da02ff18904b01e6',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/522602f87219701b29a9cfdd44386498.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2008f657ac80fab32aa173df31695ae',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/1b9252b1d6552abe76494282f9ff2566.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd87bb84d715181411c1fee7766406ca0',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/de260d17fa9c6659ca0640fc769d3457.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '750f4697ac3c966a7ef97bc3ae738073',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f3d368ba8013fb25de2f01df18cfe3e8.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdc51e22c5e149b4d4332a7014f30374',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/de49e0acbf596127d49965350bb405b3.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b85e3729a2b6818fb38294a7d1a4370b',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/32eb759e03d84251204e067411667b73.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd548849f47776a38202f6669b8c66032',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/e7f94b33d7420ab265deb06730894a7d.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c319b1a22b301b23e77b4d34d6a2d76e',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/36f88b9fb818bf0a459e754c2b548a48.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb0b6a02c4f55ebe89f2241dfec6cbf5',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/2e569c90176351303f2ef09caecc18ad.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9e0972c10d48b488478a31e50b4647e',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/5b970077db5916f988dc2739da183c10.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0d5214dc840849bbd6798823f2d7568',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/662436f9ce331505970fbd20ca2cecbd.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0002b6f015eae0eb5c0614bfd2f9b4f',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/a5885b352079ea8a4c64c96ef17d74dd.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6bfd6b9868b978787895c40640948a7',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/7bb33dbbdaf58fde59fbacf1595ac676.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36a706d28973a90cff85c3dd033a635c',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/02c1b2efcfb425b361118a336c096b9a.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccf7d42af1b0503a5c80f55aae047e01',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/9fab8df51d0b4009186bf3115d465f2f.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f25579e01a17fdb93319558b12037620',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/830337fe12e37d98a4482c18ac174eb9.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed12c0c5b2898615a93c1439f2c06880',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/3e21b1a75f9ce08f868cd95d93e91c24.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'def3b8341cf7fa6901a39f753f9a99f3',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/83f1efe3d50a3e23941d5062979ce65c.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d851f8121f76ddee35ea7c7830dd800',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/1c469e41e6d9f4613f118fb9991293be.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fa4ccf208633727186960b39a135754',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/cc9a558010959dadead90d000703bffe.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '790f52dcb60b899cd6842a9c429e6382',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/da59f6e33be9974989e6f10396de97a0.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08ce8ca2ab0724e1d884abe7610b6af2',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/cc50430df380cd7228b1f08e97e84b29.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf4618669a593aa4fbc042afd5adc495',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/caad4ded27ee3eef972e7859bc5ff138.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '220a20a8c16865695b2b093440a51cf3',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/139be6eb797e4e55d2accb320c242d0d.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbfce6b63acba3f6c417f802c8972fe4',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/0abe83403840acdfba3ab2e82dcb73a8.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba4c6a380979874457a91015532a02b2',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/68cbe2f0df134c8cecaa63e442043154.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea333d9be21a93eb5fef6eb85d06b63d',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/229c1bbe22b3143433befab8951386b2.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5140e4a51bedd7c957a111ed286de7d5',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/1528d7d9573afc7454f516049a3b908f.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f06294003cd1c877fc21a3ac7d466f7d',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/d5ded855c8542f8d894df763a664077d.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41051203d67ba4f84a43d24c9edd5fd1',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/ff8dc4adcd4c0990857c2082617f4d0c.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4159fbd4496e535dd08c29fc5f8f6a4',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/51a83b964e8877d07229c06471260654.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e012474a4277c55ead6cf401715956eb',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/9c64ce55775375414102330e0375c09f.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfbd84752054b49fd8c5739b7f8d380e',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/9945f48db771a5a60a93b28b51eddd33.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e097e09111cceaf6444f9c9e0f20bf59',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/a620c5bb87cf5553a27b87876f01bd8d.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a8cccffb86587320a6bfbbfee08710a',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/f57911878bb9ecb41d3331ee37708bc0.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd86afbc2c79762e47e8ac1ac1e3a5042',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/8fe559a132ce77d35323c973b7988d9e.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2480515b0fa54af2e3aa8dc1c2ed061e',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/b23ad58671fef617dc76dd80dba5bcac.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50cdd95ff634d7ed56306c458b366982',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/4a36357f6a73aa367e1f3bc03d3c5a10.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13176c2925a58045a2554adb5052dc8b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/91ee79e0515698b203e500d4930086c1.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30255a88197f10b4c5b12b2d8b0b613c',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/ae05702412c00c78d0ffc4189d9f4597.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a52d267b47a9eba548172ee4ec30c449',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/6db30910fe4d4fa7c97d1ac301bae484.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c7f31d050f59a85fde149b0a765c77',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/ef82f9cc4965081d62d30c22d0e425aa.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cada840cce878eead8883793500f16e5',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/599c65c42dac389d65d48637f7513cef.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e191dce51f2d174fe76e60c241f93ae',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/a72dc571a53406d98d63a78dd9c55fe7.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5068d565e5d0694ff804e70fcc346ef',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0665d29d86bc4c93e2328fcc1f7039d4.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286e319a4c46a34ded645f3e6a118acd',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/0bd76ae62828a37ad541fac7bdffbe88.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b71cdc302cdd9bb5393b8aa39d1b309',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/cb0eac0c56724871874083620d2f0b4c.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fced4669c565b74b617ef688ea57897',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/a5e385129b5daef1f3e5cb781f65d71a.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77ccb3c86d426522f6c5b41fe1786752',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/b82eb28d9034eda29e97fddc78832c9a.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c22fe2c5efeb2efd8b7942e958a8a8e7',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/5de518ad4cd6484edfe9c21bdfa0cd31.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd108b16f8075a18b6b121cb052eec98',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/191ef99337fa50d2220908efe889c1c0.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f486ebe36813252344cb0a675a92707',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/ed1d1a70f32980b0dbf05e9f773e128e.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '827e9d2f0f40d2e92623bbb2cdca6b6c',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/ffa18775d24075478f64f3c1ac0ed606.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1a4754d7a4558b9eab145548da2e17f',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/e36b77e081c9892a2a3f980525dee032.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0ffa62284e347d74037ecf9f76322c4',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/6a4fa40573a3c8d647e8ef47bc5aba88.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d4e9bac443e27d58a39054361878697',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/c60564dda4aa00a5f641f1081acdaf40.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4e11fe3156e75791177ffe4c82147b7',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/d1221b02a4797ec71d247b0d0167792e.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ff330803a452a35bb6f15a3fd93f1ff',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/8a3c6ae4430da7077d4a5d82a366faa8.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d49d657e905fb71d8e3d6ce08624aa2',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/9988312eb551e7c973fbc0e3ff4e55d6.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5340bf63d2534c59cd376f84d957404',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/1386617b7f2d1d51b34bb3e26d7e82e1.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3bb014aeefc2e77eeed1403972800c4',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/34464c707329f9b3c0cccabc36502f7c.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c2382b940c69f38b808c31207a83290',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/92b7a624545351904bd2ec0b7c4adcef.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7769de06103d24f1abd7a69b4961833c',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/d10b82f38bf2726eb3d4a3b604feba80.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9016a2f7b3c4d716fadc6da8440f436',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/c03a6b89c1dac298b5ccfa5a7b6da024.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '626acf7eea4ad42729feb3b224a69fa4',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/342896f3d25e968efd50eca12b7cf9bf.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b67a02cf6fb47399398fa881e7aa08a7',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/bf45a82dd6d7281632ec93f8743a70d9.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09a0b2eabbd3d877263ec98a899a2fe6',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/6a1eeda7cbb33807c804e91bab82c59e.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e525a32b1cf066b822940a4223aebc',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/71b7a89e99e4f60373ca4b1dde0d2ae2.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fefab653ef0f7ad9e5569008fcf3e97',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/4d0325dd45211fb16ddee1cbc7324676.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2355f46a7c5977e241b58e3341c8d545',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/d9ed01e019f2eb7953d1aab1d4de8dbe.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e1745bd4d0f9602abf7109238603c67',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/3678162e000eaeb5879804cafa692032.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '033ba1f40d7d9d6cc1872a78206ca5b2',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/18e9fce1ec0c960502e0868ae2a1cc7f.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43413bb125a48e9538a28b379c064f86',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/a087c580b221fb0a96ae9ecfa545ca0f.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be597b836784745f946e56da44b00491',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/fb718d94051aea0280831d7fb35fa359.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e14f138208cdc9fd09d40fd87df43a67',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b83eea05faea353b20099909eddfa4ff.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '994a9cbe4ac14172ecddbea3542473a6',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/30496fdf405bc93a6ca336ca8c88adee.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '888adc48b3717577d7b4a30ccd08c951',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/9fa50bee5d4baf2b20f28a7e81cdb61e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8672f72b60f27a01bcc46b8ca6ff2708',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/2111b7f72d93f5a052ab2c77a2f6edf2.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eedd9e9f334d409ea5cb331e762ded2f',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/6271e823c2ec73355e32ef4da4fb5c11.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b372a99477817904fdfdafd2b89b165b',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/ebe9d2bda3be7b7fa66726a298263d03.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29da5e5bbde552a0f56fcbc96136aa7f',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/1e53eb183220ae916b096aa28e87ff2b.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c51c9509841ab4ba58f47fec98709f0',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/df1d96a8f416c005f7f17c1e8fac7fff.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0e6421291f302475db8560bf317749d',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ebd4e43296565e75b0ae4715e5fc391f.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eca40cda7ea500089d25c7f5c77b2713',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/a2efd3d6323dee3f09a298c3ffd2acfe.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21b4f41b2989695b448d586f7b47cf2',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/f61a70fdccbbba3b76fd56dbfd020097.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deff18f1c8e88e60309e4c083be8c03c',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/71e9a40246c5cc24d565298d2cefab39.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fa290b5c07300ebc3b6d940610c2173',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/277b509124112bacca541d8112b0452a.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78c117b197c4469eda1c2ed5a30bd283',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/13adf4dcd3ca0e116768b9ad74557025.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcceabe8704bb8d67b302b7e29a21bb0',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/a331caa7bf38a99a1bf26ded0264cb75.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba1c957fb00d63463017a68fda6542fd',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/071a2b81d73cf0aba16ce914d0a35c38.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '307cced22d835630a7f68a1a88335d87',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/85d56bf2d7b8f36ae983689b60dd3690.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21a0e168606eacb8b1e1d32286ccd2e1',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/4efd5d0f341017f61ebd08e152a78ba6.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7042b40a2f268706b8f01244e2739eb1',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/efb64be237a7da7b5952d222fbd1f63b.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ed9dd24947137c3842392d385ef8775',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/a314d6b9da8080765efcae66bfd1703c.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '951b60d691984f01353bf2d8fa63e4d5',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/ca3b4fe2356f3d5ce88cd521a0b4a75f.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace9df5f500efcc687fb486b631630e4',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/8ed8347c059eba9ed80913546f092de1.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ce9993cb9e90e167dde08b8ba2ff16a',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/081fc9c631234997fb607fc3d31a8d04.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aa0bc79836212e0aad259375e650445',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/4c5864133003e54b7747fd5374b24a2b.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ebccbcad87b4f3242fa3982b245972e',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/a9bda17917b1fe174fa5347eae6796a2.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed965d5137c18ff7444fbe7bcd99493a',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/fc762d570005a15207ae9e693cdeef36.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c6ba57ddf7db7feef6598850f7f0d7b',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/207ee83d15142906032f0b803c9da22a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5bfd4b33e4ef5f56f18a4878f258777',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/3a3e52ad247ffcbf160e26dc693e43da.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdb65e43f878bf3f60565412bbf3a833',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/e00d729053b5b6d750f1aa8852d7bf71.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96faab64edd7c8b043e705fdad26b857',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/e82da6b640bda86b547ee14206cd3824.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc4e3aa7c318d34acf4d35b3bc0d7c5',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/db5708acdfc4f67812bcfc50cb4c6e82.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0017f623da1efb0c12ead237b868446b',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/b61449576b47a94e2b40cb3d5194b895.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c075bf5c33fc74be31355a0da3ca1306',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/2b56ed071bdf2c6b8803bc085b8cfd1b.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b154e846e361034916c7ac4f92738cf',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/87e55d2d85bf8484b4c57fd2913e5364.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af183ed95947662bedf62d3bea273be8',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/d8ee0d69195ab014fc44f0fda3fee511.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367776f6aea2d82827bea6821858910b',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/5bb2710aa6185527bfdf57ca56f37e11.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35254eafa249f6f9ea904b54c338df5f',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/adc6a4ba8576d4eacd149d3884c00ca3.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '699df9bcbb7ed6d442c7e4891eca94fa',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/ae1409933012e0106142da25b9d2a6a7.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b86263bbf394c1058ffb9e962b024b27',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/38fdc977ea01973400db65b6fd6fca76.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81177b9c1b2eb5280b2985af9dcd04a2',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/a8522549c608efea8fbdba19ca59230e.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de3eff9ad4a62957282a6d5515492de5',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/bc628ccf7b028310351c9a2c3e1e9056.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83ef0c245cc91db09b183d082ffb522',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/67a479bfd300d4f56a349f26d6b200ab.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784127f6fd7f54a12fb0b900c78162c2',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/c56c36406cf6decbd478246782ac52ee.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91e19e218cbf22e3e8bf04cf24f4f66c',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/89ac6ac86fee0c4d1528dfdf96840312.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14784b2faaa9b324f0dc69b60fe678dd',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/0739b23f6116954984da566d8b0f6414.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29fc9ab84781da24451f790ab8a62aaf',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/1d2df7122bcc5c2e20715f34d70e2f91.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d55f431d3d0b8c766c11ef1513cb2f0',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b38ce002a222ba6cbac5ea3cb7334976.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30b9c6dc446783e5661a210617f9030a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/391a208c1b2ba7d8b590db8c676ce48a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4c8562e05082143e69615b8bf4c6b21',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/47e13dbc0edfa5c8155f6e1880609a30.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '633b7f0b55dab746fce4d6fbf3081256',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/8b06073c98f1b5f9e3433f95a0b1eb9a.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2875c4bde69d3032d7bfe0dca30ca09',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/870da705975493be2707ce9d51744f8b.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c09a60f231af937db0279a824b778f5',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/6254458414668b1fac5183e0ac3bc8e9.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dcb6381fbe06a2fe5676e5960661fd7',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/7110e7c67eef5c9919d5536eedde0ae1.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45c07038f669035c854fb55c83e5cd9a',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/1d6112892c065f3a37a847249b67fab8.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41b8c15540ca0ad7a3834e05511169df',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/603b600c3b8eac5007cb584134c825e1.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6b567a7d9500949941630894da687ce',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/cd861308b879838317b2c2621adbceef.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acd4e7759408a5d8aae946ef5326166d',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/935139ec479c7fa04ccc3de032b86275.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a54915d6ea17711a04b319d1cee34f10',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/be4467186dce439f2834a5e0b572f5b9.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3c1734f321d0edb5a65c833217fe792',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/94c487cd8c3be0ca0753f6175932d21c.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739012374e24fedfca0f423f169b8179',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/01fe3ba4a9a15a9b8249f97ac432e539.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00db7856ed467641c2630387506bbbc',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/5f855472ce05e8c5a8a9849ba0510776.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3feb9cee223bbcaa835aef9b915f70a8',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/f1ea1e043cb8f356658734eb7f915c28.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7db8a31f45dfd00c71b4f9ae297942e8',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/9e69664db69e62a080f979de0a91d89f.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55bd7a451c67a06eb070a91c6c46733d',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/8c9152ccef93a7d2500857ca69cdb09a.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd9773dd9a4b08d5fe68f593c79a6e9e',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/d5163fb2961663d19893563a53974dd4.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '040a9e81aee8f3b251c78422ba681f92',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/fe05a26cd0cd96c5e0b75e64a71235c5.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1844f0cc680336c9d05561594a5f0ffc',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/57938f916aaedb76aea231459539f667.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3126de143576746aa3f243766af02623',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/f046f4a3be4cbe8471382019bfc66b25.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '646283a7bbe9b828885dd8db1daae89f',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/7aff2f3643a12bef3144a5246521942e.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd339b0331a9c704a7c6b44946518033b',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/0c2ffdc132982eecf9d7a18556f60041.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0138c31463d6594dad65ef85629aacf5',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/6f258d802867396495180f7b1210e21e.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5c8f75a7d394584924c3d71ab720f8c',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/8e479f047a077034575a88ed1cdf8c37.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2df9597c39269247b9248a0c7d78455b',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/ee1630aee890b91a852fedd4c312598b.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '778d81ba9bf135d4fb7af7ca57652933',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/6e66c3aab46746b46e6eeaf57e58c0bb.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a884e633b96103a7d0dcd7ef43ce7a49',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/f413535b513974ca8cd577aef121e3ce.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12205541cce01161f3e34dbf6bf710f9',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/ffe04e98990e7eddaf56fde3d398a5f4.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3248d5bd04b64b317e1921316d90363b',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/27518e59c0a99ed38f4c7b5408cd613c.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0b13591b64c778c91b9ba1d9811e96a',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/43bedceeb1ca350e95f6212b62ae37da.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f692baac8eeebf192191c3a02983dbcf',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/34a27eb42393062f58ed5c3cf7a571ee.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9faf6f1a3ad056939a711d1d31b8c184',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/0e901d978ef7ce897137238fa112f231.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '903a26bbc18cccc37ec22725505c2a74',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/854c09f31208104baa5c1558aeb78ef2.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed8e792b8dc825569f99e8d68aff37c4',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/d1e3508d0263eee8bf4bc977b710f14b.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f325aed600703df42b946adb1f5f801',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/cc37badf6d5ac279f695f4f06d92861d.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf7f6ab0c180737f45b127cf6fe25e42',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/ac87fb5b905a073e6580b67be6b4d3df.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e0ac17d4557835a7cdb6197e38ab194',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/54535e2ac21e1e409c36aa469ac82149.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4936b3ce925c9115cd74ad589afcc08',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/0343ee9744eb70bc0433e34e5b813b47.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7b7e1a08c5af257562fd7080bbd15db',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/a023b7782501536939c7419fd81bde23.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d9e925c2f2309a276f83a2991f5d888',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/fdcd8c78d53ea51183b51744bc626add.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2783b243b3664e97277cb84e298d0e37',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/c53cc12f1629c4935fca66be529af41a.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '217150514c4b2d9b9d5f7120956b8b3e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/2e32f0d068d09c03d4871770b7f29160.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21bd1a60e1673a6b7b284f369b1eec9c',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/c96e88a8b9a4de7e552d10eec4a00bc0.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '838c3ee2ff5c877c3b6051943c74f39c',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/1243147fab67d360c053a866c54ad2c1.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '326dc3edc147c85559162e62efe921d2',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/3f7f89f7df3be03aaa60074acaff746c.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26e912c4439c1266bf3a8eb98ce9281a',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/879703a9f6dbe4d69b15bdddaebaf3a0.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae07eaa240b79932b4c2f9109049253',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/76216d4dc7aa6970416183d5df866660.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ee365608167c4155ef4a5f03454f2f5',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/56482a294d53f936b63550a3a52e03a8.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4962e264f9d6fd2ed5db79698f77cd2b',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/b52af7a1ee741c9d4909b9717090604a.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77a4dcc8331e02994cd5a96924ea4df8',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/c55de67967be26369c5c41d37b45690c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00f94080f655033cb92c222a10995f7',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/d517920a3ec9d901b8c52ff1ad42a2c5.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6adc477f0a2f03f666c6ef287005bea7',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/d67fce3d6eed06be17883056e0c6e9ac.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15b3e932621383fa96faa18c7dd0c398',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/6fa9adfc75e6fd9bbd47d8dc64a4a4d4.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db2c3c7b12f5ba0151c7484d52eb4a86',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/9789c4ba38936dbaf8f265bd611c7b93.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe53ce7ff4ee029dde4044130dd63954',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/c1fc63ea2d6c068cf56ef90162105f09.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7f887dd5e3586c28075efa72d5af6b4',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/c6511dd7e31569b95091d7152e79fae9.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14ea607b4e191a5d4d7e942158254315',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/6687624e8dfcb1cd60d4daa60fb00742.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac7fa10fd56daccadf28c1b15bfd64e0',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/a10a5ab438acc794a0289bd628a2cb61.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c99eeaf5f6e4cdd93bc7df2cad2c06f',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/bc69b644537b869366a3f3c1bcedca1d.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38b25f0284c2a358e6986bdc3b3bdd05',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/201b3b275da47f68f87974174df300f4.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f73e793b6cfe81cd6f4fabee9042ee0c',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/36627ab9656869e994cddd2ea88a5416.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24f0ca36be6d5d8005851f6652ce431c',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/105bdb37adeb3927eb34c87a6b7f40b9.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1de4629bedb2ca5d3c9fb0cf3912f134',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/30d6ba968889d537d1c31989a4506893.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24ff448ea734cf35fc29deedfcf6e35b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/92c774e72ca8ad5d3a1765bb314ee157.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64c0e6d0cb0b85f6d283bf5d4edadb3b',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c506c0e195d30501c82676158f279093.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9d8c3b81ba0aa612c7f42eb68ea17b3',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/9a7e135afd8bb4e3db6d946db5818218.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '687a3c4321ef485db72426198667b2cc',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/801f9bbce12dfea7f4e112b244f3d309.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01148c3b9207edef1c72d4f9c9787b61',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/8d2628d6403575f7f419fc7a7902a8a0.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b716e553e802283b2aab4724a42f1209',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/c4d42909179fb63ec3a775642192606f.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71b1bd227fc88bd2855c72ad671f1cce',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/e92b4be711be9b66f0d5c89df2cec808.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef3f7c7e551cd75a7c609fe56fcf53b9',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/6097ef1c5882e4430fb948c06e62670b.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08bd3b7fd786b89b825b2be09fc62466',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/34f3631cc3aee4cade2cd0c9d4bc7c1f.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '001c98cad425280a097ec65df0a3302b',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/21fc876263ae1648e9b810e9fd6d158d.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89ff7338ea90cc726ab9ef3bdab593ac',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/3a351f89a5d4d79dc0a3988225489bb8.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3db6195c2ad3b1e69780563a092557c1',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/936ec0cabd27f47e265c841e68e6ac1c.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bec2ede604aa39cd4b156fa44f5ec1d',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/c414bdf7dda6268918623a200e82a0d0.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5daa6a4c163e18990ba2bac73e3af0f',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/bcce5764e082b8962649b5a49c1e643d.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c69a7f05a9f5e8949528e3e6f65ee13',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/239f6496384d5d9655573138429d5ae9.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffec6b7ee6d3e3de36feb5d621aa6609',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/8a8d442d574221d3363f5c68debb4354.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec0ddc7653cf703d72ed5a66e374419d',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/58e96741153a16a461aad9bc24658d0f.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47b24955aa0069ab7c0d871891befa78',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/61114032ef7a07242be3b70616f28147.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36155928ccad5317baef3c0129470365',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/0716b6b9d906d304b9ec14d6d854262a.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db74ebf27c135053723629ee4c138864',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/11e8510e6105cb425c0ab84e4a419df2.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a5b5b66900f6f09c20fea82eefa9912',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/65e9957ace1e55d704da3045fa09fd55.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c5c222a9829f015d5d76cfe303931e2',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f877679aa3662aa64bc5b5d423b88ce1.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aa0c556a25805d5d7f1adbc9b84bfc0',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/364f0c54698765c2201cd5039dc2cdee.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685f7b60c3e66e41dd0efa9e6e008174',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/2d42b782a7bb732a191149c3ac11607d.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db8d7909bf8feed661905a9f1a7fbfa5',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/c12c151b93e2984751cadacc695b1993.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b4924be2651b35c49b8c5deb837009c',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/60d2d8e158ae2a75ef74c33200ee9a41.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83e9cd90ae895faf547c3a95ea23b6df',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/e91b8c761fffbefb3b99414b00be6c43.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ccd34aa75787f8d095f9e6b88e65c95',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/8ac321235e8557567a20d129265a3cd4.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a13d8b0b30a0bfe0df6b576e4714b6',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/10ed2aa5bf6752fceb290a36bee736e1.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e16868a046b9e8671e406bbca81bdf30',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/e9982017a59357e1ecf8b28b27ed0e0d.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9023049c9e4361c4dd579e2f4613c784',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/6b038358cf4a100389ad8e1d36e87460.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fe3ac7886432df998fbfef7bd73c644',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/cb70ecbf4277ab8b4f9d05ea15ecfade.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '612302ca2757bbd3f529c703d3f5770e',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/ec64ec3d50891bac0aca783c38195685.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2218bec4039d196a4089d60d1746cb81',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/4fd625fde89106d547a5457a1bd2d0ba.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '657d5153c057eb5a356b23217cbfd7ba',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/97913b163171ad4fa02b86da8399a9de.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8608a54f051b5306fd30b2014555969',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/1e84e4c0d44946b60d593e5475c3e3c4.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c2c6c32c74b28f0ea360a1f2a59b3c4',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/f194ad36c4f54ccd25e996f9682343b5.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3a88d0348221de51a2cdb74b817b510',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/c6898fc2d30994641f25734061fcfee4.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ef812e5b615e9aac6775bde341d9267',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/098d30650dbe0d04f017e6cfd641712f.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2b765a0edef20f864271308446155e9',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/a2e13832a5871767cc56ebcef75960c5.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '44dd869d91ca180e3be723e3922ba716',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/3ac6bb8253bcf380cb5b71e1912dd221.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '76d37018e4660979a8bc836f9e6450c8',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/bdebd3ac76cdd703316f518bccfa2dbf.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '2d240ab8bd98b2971eb5c30a26fd4559',
      'native_key' => 1,
      'filename' => 'modUserGroup/3fb79b6ad6aa135aae0c00d66ccad5f7.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '07dd38badde5f462a2a46a582211a55a',
      'native_key' => 1,
      'filename' => 'modDashboard/347c9af3fb8125c6429beffbeab1e7af.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '89714d5cdf25a46a707f3e0dcbfb9684',
      'native_key' => 1,
      'filename' => 'modMediaSource/56557999feff0a87b8d72c29f9397e46.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b1e019db3ff46b34e5af833bdce08eb0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e72878ae5fe922d7fa656b6747b85a61.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd0afb3a0b7781a70c6983c9c57f747b5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/cf72440d83df9d9e067facc3223e7922.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e4fb141104f6f745e999539356f4b3f6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/11bd1901443ed380009cde174ce49019.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '141a3014ce430a56380058492831949e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/26191e28a6cd28b9381981943d568db2.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2bbf0f46f4ddd63203040adf704c1cea',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3d44438bc07e7ef4ea81c164039a966f.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '10eeeb0370feb30495cf01a7cbb95103',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/cc49dce1dda69ba37c4ee05f0d1a4e27.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '71d533429e9eb51cb1bc15dbd97dec88',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/ed0c1c2bfdf239eddbe94f12381ab681.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b30c2a9df17a33067c6308926f538137',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/994c8a2be8bd761b24221261937e6e36.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2594feb3a44354f49a8c1e835237821b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a1df6cdbd722d56abb2fee3ac67e6bca.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '98cf62b4285f79cc39593554d34d4d9d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/78abcb0b1e40b05d148306031d47b5b2.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4e6eb34e2ecca42b43b91f270ba0c13a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6498079599c608ee6c31a3ebddde09d6.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9f46c737d60997a88ea99de18cc034ab',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/348db326546923e8f204162961a7614b.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5628e62993ba72752f763c71ef3e9af7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/516ee1b84ed02a8b3cc897d9383e6367.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ece1cbe8cd953e8863dcbce02f153527',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1f8967463e98f21447f7f93fba414d2c.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2d29c21f62fcd5b8f5bdc71ed08f8ce0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8a1e1fc59204f61ddde8e3ade052803f.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c0614db6c321d7b40db73c894690291b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bd921a635d71a6f11d406bd13984f770.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b613510563f0c4285e8641c7acbb5e45',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/814a7ddfcfed85ef15144b559480af0e.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7887d33b09eb342c357a3beee5e4f239',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6356d7fc928087b34ba624cceb7c8baa.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c99853925861399e14ab633df37db85d',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/489948f142e0f19d45abaaeab2d08546.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '28e8e7363f586f1b5c057ca205fa2d2e',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/69fefe7c2b7af2dd3947a2377854c9be.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c74548f1d8691f51ec276222ea8caae5',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/e76af6041559c93569fd044c6873f2ef.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '18566c64f34b2b291c439a88813215a6',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/e7b54f12d2d4a97806fc25994fdc8c64.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '81dd850b8319d839a47f3ae70448f1d9',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/13b6c233a297251ac29c0b458b921a87.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1bcc64e38e5ff5aa0dc7ed7e486375b2',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/150720e92997f8558ba6d6d1c61b189f.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6a654ce23f522da389aac9c140174b20',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/14e44359d5e32a26afca08701addf111.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '28212da800f2f11cabb49591f0a051e0',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/7b8ba296cae4e02c3dc59377695bbb1c.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ac71159e31aa8e6527dba6c830fe0f86',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/57325ad731a934b392fcd69bc329b621.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0b03d28406530259193e3b145eae1953',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/8a1c89bd37fa55f5fcb12b46cc751101.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '42c0b26637572a7bff1d61a58f22cae5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/e5f523d02683d8fc8e160fc70e96344f.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '234458eebe6d25388bad4a8117945c63',
      'native_key' => 'web',
      'filename' => 'modContext/beada694127e00c7caacf4a6e0e1c2cb.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '183c56eab4d2caf5b88a44325cf24b8f',
      'native_key' => 'mgr',
      'filename' => 'modContext/0d7cb0d8ebad451b893bcbdea7e63f07.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3e53b6e023210bb8733ada138fee753b',
      'native_key' => '3e53b6e023210bb8733ada138fee753b',
      'filename' => 'xPDOFileVehicle/ba2b54719b37ebe8e83826d092a5c9bb.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '694d9ad9815d14818dd52fc7111fac5d',
      'native_key' => '694d9ad9815d14818dd52fc7111fac5d',
      'filename' => 'xPDOFileVehicle/bbf13f2d73102563bcb0c0f34cd3c128.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5828109726d68936e2390aa2db5c4940',
      'native_key' => '5828109726d68936e2390aa2db5c4940',
      'filename' => 'xPDOFileVehicle/22b0bc8a6c13bf5c5d8d30264cbae4d6.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'de78f571dcef8e6a9e8e898249a263bf',
      'native_key' => 'de78f571dcef8e6a9e8e898249a263bf',
      'filename' => 'xPDOFileVehicle/2ad7b155e89236583fb9bec7a54614d1.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3a5f53768d264a0cee753768255b23b1',
      'native_key' => '3a5f53768d264a0cee753768255b23b1',
      'filename' => 'xPDOFileVehicle/30d32c53dad267ac6ea7fa976735cf0a.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3395391661b51b22c10a471fff0fdd78',
      'native_key' => '3395391661b51b22c10a471fff0fdd78',
      'filename' => 'xPDOFileVehicle/5369d27b37c905f2be49a586fe2c8864.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9f8c00763dfce60d9d1eb315ebd30b2e',
      'native_key' => '9f8c00763dfce60d9d1eb315ebd30b2e',
      'filename' => 'xPDOFileVehicle/5e169ae4a9ff6c08310fab5e7b8e1e4e.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6d5da89ba7d798c11169209c83669f95',
      'native_key' => '6d5da89ba7d798c11169209c83669f95',
      'filename' => 'xPDOFileVehicle/a148882e26c4e4d3d41f07e707e1f728.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd9357c8ac181c496dbf5933ca69aba84',
      'native_key' => 'd9357c8ac181c496dbf5933ca69aba84',
      'filename' => 'xPDOFileVehicle/d83ae06215688224c5abb5c1f2103485.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1f18005e15758a979b047329c2c4bee3',
      'native_key' => '1f18005e15758a979b047329c2c4bee3',
      'filename' => 'xPDOFileVehicle/609dba858be64c0152d125213d16bf67.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f4cedc7cb3296de225e2ca0df2c42ad1',
      'native_key' => 'f4cedc7cb3296de225e2ca0df2c42ad1',
      'filename' => 'xPDOFileVehicle/fa8a70bb8b4cabeac99edd72a63781c0.vehicle',
    ),
  ),
);